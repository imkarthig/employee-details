export const getEmploye='getEmploye';
export const setEmploye='setEmploy';